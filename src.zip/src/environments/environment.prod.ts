export const environment = {
  production: true,
  backend: '/',
  google_map_key: 'AIzaSyBLnHmlaxo_wzKhip_KPfPOGjAFC7najhY'
};
