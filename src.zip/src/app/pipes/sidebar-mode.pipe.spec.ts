import { SidebarModePipe } from './sidebar-mode.pipe';

describe('SidebarModePipe', () => {
  it('create an instance', () => {
    const pipe = new SidebarModePipe();
    expect(pipe).toBeTruthy();
  });
});
