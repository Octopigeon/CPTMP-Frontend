export const ErrorCode = {
  0: "登录成功",
  1: "登录凭据错误",
  5: "帐号无效"
}
